function refreshList() {

   $('#list').empty()

   $.get('/list',

      (data) => {
         for (let task of data) {

            $('#list').append(

               $('<li>')
               .append(
                  $('span').text(`TASK : ${task.name} &nbsp;&nbsp;`)
               )
               .append(
                  $('span').text(`DESCRIPTION : ${task.description} &nbsp;&nbsp;`)
               )
               // .append(
               //    $('input[type="checkbox"]'.attr("checked", "checked"))
               // )
               .append(
                  $('<span>').text(task.name)
               )
            )

         }
      }
   )
}

$('#add').click(() => {
   console.log('clicked')

   $.post(
      '/add-item', {
         name: $('#name').val(),
         description: $('#desc').val()
      },

   )

   refreshList()
})

refreshList()